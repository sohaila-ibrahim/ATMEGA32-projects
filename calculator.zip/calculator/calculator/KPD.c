#include "STD_TYPES.h"
#include "BIT_MATH.h"

#define F_CPU 80000000UL
#include <avr/io.h>
#include <util/delay.h>

#include "DIO.h"
#include "KPD.h"

 u8 KPD_U8KEYS[4] [4]= KPD_KEYS;
/* array for keypad rows with specific row number */
u8 KPD_u8_ROW_PIN[4]={KPD_R1_PIN , KPD_R2_PIN , KPD_R3_PIN , KPD_R4_PIN};

/* array for keypad columns with specific column number */
u8 KPD_u8_COL_PIN[4]={KPD_C1_PIN , KPD_C2_PIN , KPD_C3_PIN , KPD_C4_PIN};




void KPD_VidInit(void)
{
		DIO_VidSetPortDirection(KPD_PORT,0x0f);
		DIO_VidSetPortValue(KPD_PORT,0xff);
}


u8 KPD_U8PressedKey(void)
{
	/* value of the counters for loops */
	u8 Local_U8CounterR,Local_U8CounterC,Local_U8Flag=0;
	/* flag to check if the pin pressed or not */
	u8 Local_U8Pressed;
	/* value of the pressed key and initial has value of no pressed key */
	
	u8 Local_U8ReturnedKey=KPD_CHECk;
	/* start loops to check the  Local_U8Pressed  */
	for(Local_U8CounterR=0;Local_U8CounterR<4;Local_U8CounterR++)
	{

		//deactivate row
		/* read the value of the current row */
		DIO_VidSetPinValue(KPD_PORT,KPD_u8_ROW_PIN[Local_U8CounterR],DIO_LOW);
		
		for(Local_U8CounterC=0;Local_U8CounterC<4;Local_U8CounterC++)
		{
			//check COL
			/* activate current column to check it */
			Local_U8Pressed= DIO_u8GetPinValue(KPD_PORT,KPD_u8_COL_PIN[Local_U8CounterC]);
			/* if the value is 0 that mean the key is pressed */
			if (Local_U8Pressed==DIO_LOW)   //switch is pressed
			{
				//for bouncing
				_delay_ms(20);
				//return value
				while(Local_U8Pressed==DIO_LOW)   //for the delay of pressed
				{
					Local_U8Pressed=DIO_u8GetPinValue(KPD_PORT,KPD_u8_COL_PIN[Local_U8CounterC]);
				}

				 Local_U8ReturnedKey=KPD_U8KEYS[Local_U8CounterR][Local_U8CounterC];

				//flag

				Local_U8Flag=1;
				break;  //to exist for loop



			}
		}
		/* deactivate current column to check the next column in the next loop */
		DIO_VidSetPinValue(KPD_PORT,KPD_u8_ROW_PIN[ Local_U8CounterR],DIO_HIGH);
		if (Local_U8Flag==1)break;

	}
	/* return the value of pressed key in the keypad */
	return Local_U8ReturnedKey;
}
