#ifndef KPD_H_
#define KPD_H_

/* define PORTB for keypad row and PORTD for keypad column */
#define KPD_PORT          PORT_A

/* define pins from PIN0 to PIN3 in PORTD for keypad rows */
#define KPD_R1_PIN        PIN_0
#define KPD_R2_PIN        PIN_1
#define KPD_R3_PIN        PIN_2
#define KPD_R4_PIN        PIN_3


/* define pins from PIN4 to PIN7 in PORTD for keypad columns */
#define KPD_C1_PIN        PIN_4
#define KPD_C2_PIN        PIN_5
#define KPD_C3_PIN        PIN_6
#define KPD_C4_PIN        PIN_7

#define KPD_CHECk         0xff
/* the values of the keypad with (COL_NUM * ROW_NUM) */
#define KPD_KEYS   {{'7', '8', '9', '/'}, \
	                {'4', '5', '6', '*'}, \
				    {'1', '2', '3', '-'}, \ 
					{'C', '0', '=', '+'}}


void KPD_VidInit(void);

u8 KPD_U8PressedKey(void);

#endif
