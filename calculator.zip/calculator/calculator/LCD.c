#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "DIO.h"
#include "LCD.h"
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>


// send CMD   RS=0 RW=0
void LCD_VidSendCMD(u8 copy_U8CMD)
{
	/* set RS pin to low...RS low => command  */
	DIO_VidSetPinValue(LCD_CMD_PORT , RS , 0);
	
	/* set RW pin to low...RW low => write  */
    DIO_VidSetPinValue(LCD_CMD_PORT , RW , 0);
	
	/* send the command to data pin in LCD */
    DIO_VidSetPortValue(LCD_DATA_PORT,copy_U8CMD);
	
    DIO_VidSetPinValue(LCD_CMD_PORT,EN,1);

    _delay_ms(1);
    DIO_VidSetPinValue(LCD_CMD_PORT,EN,0);
}
//send data
void LCD_VidSendChar(u8 copy_U8Char)
{
	/* set RS pin to high...RS high => data  */
	DIO_VidSetPinValue(LCD_CMD_PORT , RS , 1);
	
	/* set RW pin to low...RW low => write  */
    DIO_VidSetPinValue(LCD_CMD_PORT , RW , 0);
	
	/* send the command to data pin in LCD */
    DIO_VidSetPortValue(LCD_DATA_PORT,copy_U8Char);
	
	/* set enable pin to high then low to generate pulse */
    DIO_VidSetPinValue(LCD_CMD_PORT,EN,1);

    _delay_ms(1);
    DIO_VidSetPinValue(LCD_CMD_PORT,EN,0);
}
//initialization important for direction
void LCD_VidInit(void)
{
	/* set the PORTA output for the data of LCD */
	DIO_VidSetPortDirection(LCD_DATA_PORT,0xff);

    /* set the pin 0,1,2 in PORTB output for control of LCD */
	DIO_VidSetPinDirection(LCD_CMD_PORT , RS,1);
	DIO_VidSetPinDirection(LCD_CMD_PORT , RW,1);
	DIO_VidSetPinDirection(LCD_CMD_PORT , EN,1);
     
	 /* wait for 35ms */
	_delay_ms(35);
	
	/* set LCD configuration to 2 lines and 5*8 font size */
	LCD_VidSendCMD(LCD_FUN_SET);
	_delay_ms(1);
	/* turn on the LCD and disable showing a cursor */
	LCD_VidSendCMD(LCD_ONOFF);
	_delay_ms(1);
	/* clear display */
	LCD_VidSendCMD(LCD_CLEAR);
	_delay_ms(2);
}

//function of string
void LCD_VidSendString(u8 *copy_U8Ptr)
{
	/* loop until reach the last char of sting */
	for(u8 Local_U8counter=0;copy_U8Ptr[Local_U8counter]!='\0'; Local_U8counter++)
	{
       /* send char by char of the string to the LCD */
	   LCD_VidSendChar( copy_U8Ptr[Local_U8counter]);  //NULL='\0'

	}
}
//function of location
void LCD_VidSendLocation(u8 copy_U8LineNum,u8 copy_U8CharNum)
{
	switch(copy_U8LineNum)
	{
	  case LINE_1:LCD_VidSendCMD(0x80+copy_U8LineNum);break;
	  case LINE_2:LCD_VidSendCMD(0xc0+copy_U8LineNum);break;
	}

}
//function of clear

void LCD_VidCLR(void)
{
	/* send the clear screen command to the LCD */
	LCD_VidSendCMD(LCD_CLEAR);
}
//send number
void LCD_VidSendNum(u32 copy_u8Num)//123%10
{
	u32 Local_u32Reminder=0,Local_u32Reversed=0;
	while (copy_u8Num!=0)
	{
		Local_u32Reminder=copy_u8Num%10;//2  1
		Local_u32Reversed=(Local_u32Reversed*10)+Local_u32Reminder;//3
		copy_u8Num/=10;//12

	}
	while(Local_u32Reversed!=0)
	{
		LCD_VidSendChar((Local_u32Reversed%10)+'0');
		Local_u32Reversed/=10;
	}
}
//special char in CGRAM    location >>>.data
//LCD_MoveCursor function
void LCD_VidSendSpecialChar(u32 copy_U8CharNum,u8 *copy_U8Ptr)
{
	/* variable to know which address in the LCD will to cursor moved to */
	u8 Local_U8Counter;
	/* the first address in the second line is 0x40 then add it to the LCD address */
	LCD_VidSendCMD(0x40+(copy_U8CharNum*8));
	
	for(Local_U8Counter=0;Local_U8Counter<8;Local_U8Counter++)
		LCD_VidSendChar(copy_U8Ptr[Local_U8Counter]);
}
void LCD_NumberToString(s32 Copy_s32Data)
{
	/* string to hold the ASCII result */
	u8 str[16];
	/* use itoa C function to convert the data to its corresponding ASCII value*/
	itoa(Copy_s32Data, str, 10);
	/* display the string */
	 LCD_VidSendString(str);
}
