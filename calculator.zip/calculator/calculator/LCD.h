#ifndef LCD_H_
#define LCD_H_

#define LCD_DATA_PORT      PORT_C
#define LCD_CMD_PORT       PORT_D


#define RS         PIN_5
#define RW         PIN_6
#define EN         PIN_7

#define LCD_FUN_SET      0b00111000
#define LCD_ONOFF        0b00001111
#define LCD_CLEAR        0b00000001

#define LINE_1        0
#define LINE_2        1

void LCD_VidSendCMD(u8 copy_u8CMD);
void LCD_VidSendChar(u8 copy_u8Char);
void LCD_VidInit(void);
void LCD_VidSendString(u8 *copy_u8ptr);
void LCD_VidSendLocation(u8 copy_u8LineNum,u8 copy_u8CharNum);
void LCD_VidCLR(void);
void LCD_VidSendNum(u32 copy_u8Num);
void LCD_VidSendSpecialChar(u32 copy_u8CharNum,u8 *copy_Pu8ptr);
void LCD_NumberToString(s32 Copy_s32Data);

#endif
