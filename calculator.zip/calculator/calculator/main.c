#include "STD_TYPES.h"
#include "BIT_MATH.h"

#include "DIO.h"
#include "LCD.h"
#include "KPD.h"
#define  F_CPU 80000000UL
#include <util/delay.h>

#include <string.h>

#include <avr/io.h>

int main(void)
{
	/* declare variable used in main file */
	s32 num1, num2, result;
	f32 floatResult;
	u8 i, j, k, floatFlag;
	/* call the function of the KEYPAD initialization */
	KPD_VidInit();
	/* call the function of the LCD initialization */
	LCD_VidInit();
	/* print my name on the LCD */
	 LCD_VidSendString("Sohaila***Ibrahim");
	 /* move the cursor to the second row of LCD */
	 LCD_VidSendLocation(1,0);
	 /* print the project name */
	 LCD_VidSendString("Mimi calculator");
	 /* wait for 2 second */
	 _delay_ms(2000);
	 /* clean screen */
	 LCD_VidCLR();
    while(1)
    {
      /* declare the string used in super loop */
	  u8 operator,temp;
	  u8 IN[16] ="" ,num1_str[8] ="" ,num2_str[8] ="" ;
	  
	  /* at first all number is 0 */
	  num1 = 0, num2 = 0;
	  /* flag to check if there is a float numbers in division */
	  	floatFlag = 0;
		i=0;
		while(1)
		{
			if(i<16)
			{
				/* get input from the KEYPAD */
				temp = KPD_U8PressedKey();
				
				/* loop until a key is pressed, if key is pressed then the loop will break */
				while (temp == KPD_CHECk) 
				{
				   temp =  KPD_U8PressedKey();
				}	
				/* if the clean screen button is pressed in KEYPAD */			   
				if (temp == 'C') 
				{
					/* clean the LCD screen */
					LCD_VidCLR();
					/* make the input string empty again */
					strcpy(IN, "");
					/* start a loop from first again */
					i = 0;
					continue;
			}				
			/* put the value of key pressed in the input string */	
		    IN[i] =temp;
			
            /* if = button is pressed, then it is the end of operation */
			if(IN[i] =='=')
			{
				/* show = in the LCD */
				 LCD_VidSendChar('=');
				/* the null character to indicate the end of string */
				IN[i] = '\0';
				/* break the loop */
				break;
				}
				/* if the button pressed is not = of C then send the button value to LCD */
				 LCD_VidSendChar(IN[i]);
				/* increase the index of input string */
				i++;
			}
			
		}			
		
		/* reset all counters */
		i = 0, j = 0, k = 0;
		while (IN[i] != '\0') 
		{
			/* if the operator char is found in input string */
			if (IN[i] == '*' || IN[i] == '/' || IN[i] == '+'|| IN[i] == '-') 
			{
				/* then store the operator in the variable */
				operator = IN[i];
				/* increase the index of input string */
				i++;
				/* loop to take the second number of the operation and store it in a string */
				while (IN[i] != '\0') {
					/* store digit digit of the second number in the second number string */
					num2_str[k] = IN[i];
					/* increase the index of second number string */
					k++;
					/* increase the index of input string */
					i++;
					
			}
			break;
}
/* if the operator is not found, then we still in the first number part */
else 
{
	/* store digit digit of the first number in the first number string */
	num1_str[j] = IN[i];
	/* increase the index of first number string */
	j++;
	/* increase the index of input string */
	i++;
}
		}
		/* function to convert string to integer to use it in the operation */
		num1 = atoi(num1_str);
		num2 = atoi(num2_str);
		/* switch case to know which operator is chosen */
		switch (operator)
		 {
		     case '+':
			   result = num1 + num2;
			   break;
		      case '-':
			   result = num1 - num2;
			   break;
		      case '*':
			    result = num1 * num2;
			    break;
		      case '/':
			if (num1 % num2 == 0)
			 {
				result = num1 / num2;
			}
			else 
			{
				/* else, there is a floating part and start to calculate it */
				floatResult = (f32) num1 / num2;
				/* take the integer part of the result */
				result = num1 / num2;
				/* make the flag is true */
				floatFlag = 1;
				/* get the first 3 digits of the floating part */
				floatResult = (floatResult - result) * 1000;
			}
			break;
		}
		/* start to print the result of the operation */
		/* check if there is a floating part in the operation */
		if (floatFlag) {
			/* if the integer part of floating is 0, then send it */
			if (result == 0) {
				LCD_VidSendChar('0');
			}
			 else 
			 {
				/* if the integer part of floating is not 0, then send the all number */
				LCD_NumberToString(result);
			}
			/* send the dot to the LCD */
			LCD_VidSendChar('.');
			/* print the floating part of the operation */
			LCD_NumberToString((s32) floatResult);
		}
		 else
		  {
			/* there is no floating part, then send the integer number only */
			LCD_NumberToString(result);
		}
		/* loop to wait for the C button is pressed to clean the screen for new operation */
		temp =KPD_U8PressedKey();
		while (temp != 'C') 
		{
			temp = KPD_U8PressedKey();
		}
		/* the C button is pressed and we will clean the screen */
		LCD_VidCLR();
	}
}
		